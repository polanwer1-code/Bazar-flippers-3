package com.example.bazaarflipper;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Polls sources in the background and caches the merged result. */
public final class FlipService {
    private static final List<FlipSource> SOURCES = List.of(new HypixelSource());
    private static final ScheduledExecutorService POOL = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "bazaar-flipper");
        t.setDaemon(true);
        return t;
    });

    private static volatile List<Flip> latest = List.of();
    private static volatile String status = "Loading...";

    public static void start() {
        POOL.scheduleWithFixedDelay(FlipService::refresh, 0, Config.REFRESH_SECONDS, TimeUnit.SECONDS);
    }

    private static void refresh() {
        List<Flip> merged = new ArrayList<>();
        for (FlipSource s : SOURCES) {
            try {
                merged.addAll(s.fetch());
                status = "";
            } catch (Exception e) {
                status = s.name() + " error: " + e.getMessage();
            }
        }
        if (!merged.isEmpty()) latest = merged;
    }

    public static List<Flip> flips() { return latest; }
    public static String status() { return status; }
    private FlipService() {}
}

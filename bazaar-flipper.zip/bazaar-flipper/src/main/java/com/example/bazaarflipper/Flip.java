package com.example.bazaarflipper;

/** One ranked flip opportunity. */
public record Flip(String id, String name, double buyOrder, double sellOrder,
                   double profitPerItem, double marginPct, double hourlyVolume, double score) {}

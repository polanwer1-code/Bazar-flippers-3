package com.example.bazaarflipper;

/** Simple constants for now; swap for a JSON config later. */
public final class Config {
    public static double TAX = 0.0125;              // 1.25% Bazaar sell tax (lower with Community Shop upgrades)
    public static double MIN_MARGIN_PCT = 2.0;
    public static double MIN_HOURLY_VOLUME = 500;
    public static double SCORE_VOLUME_CAP = 5000;
    public static int LIST_SIZE = 10;
    public static int REFRESH_SECONDS = 60;
    private Config() {}
}

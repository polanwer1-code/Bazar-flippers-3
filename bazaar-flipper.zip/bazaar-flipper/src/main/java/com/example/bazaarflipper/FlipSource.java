package com.example.bazaarflipper;

import java.util.List;

/** Anything that can produce a ranked flip list. Hypixel API is the only source. */
public interface FlipSource {
    String name();
    List<Flip> fetch() throws Exception;
}

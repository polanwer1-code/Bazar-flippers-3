package com.example.bazaarflipper;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Display-only overlay: reads public price data and draws it. No clicks, no orders, no automation. */
public class BazaarFlipperClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        FlipService.start();

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof AbstractContainerScreen<?>
                    && screen.getTitle().getString().contains("Bazaar")) {
                // Renamed from afterRender in 26.1 - verify against your Fabric API version.
                ScreenEvents.afterExtract(screen).register((s, graphics, mouseX, mouseY, delta) ->
                        draw(graphics, s.width));
            }
        });
    }

    private static void draw(GuiGraphicsExtractor g, int screenWidth) {
        var font = Minecraft.getInstance().font;
        List<Flip> flips = FlipService.flips();

        String title = "Top Bazaar Flips";
        List<String> lines = new ArrayList<>();
        if (flips.isEmpty()) {
            lines.add(FlipService.status().isEmpty() ? "No flips found" : FlipService.status());
        } else {
            for (Flip f : flips) {
                lines.add(String.format(Locale.ROOT, "%s  +%.1f (%.1f%%)",
                        f.name(), f.profitPerItem(), f.marginPct()));
            }
        }

        int width = font.width(title);
        for (String l : lines) width = Math.max(width, font.width(l));

        int pad = 4, lineH = 11, margin = 6;
        int boxW = width + pad * 2;
        int boxH = lineH * (lines.size() + 1) + pad * 2;
        int left = screenWidth - boxW - margin;   // right side of the screen
        int top = margin;

        g.fill(left, top, left + boxW, top + boxH, 0xAA000000);
        int x = left + pad, y = top + pad;
        g.text(font, title, x, y, 0xFFFFD700, true);
        y += lineH;
        for (String l : lines) {
            g.text(font, l, x, y, 0xFFFFFFFF, true);
            y += lineH;
        }
    }
}

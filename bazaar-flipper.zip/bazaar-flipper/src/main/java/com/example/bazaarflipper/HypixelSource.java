package com.example.bazaarflipper;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** Official Hypixel public API. No key needed for this endpoint. */
public class HypixelSource implements FlipSource {
    private static final URI URL = URI.create("https://api.hypixel.net/v2/skyblock/bazaar");
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10)).build();

    @Override public String name() { return "Hypixel API"; }

    @Override
    public List<Flip> fetch() throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URL).timeout(Duration.ofSeconds(15)).GET().build();
        HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() != 200) throw new IllegalStateException("HTTP " + res.statusCode());

        JsonObject products = JsonParser.parseString(res.body()).getAsJsonObject().getAsJsonObject("products");
        List<Flip> out = new ArrayList<>();
        for (Map.Entry<String, com.google.gson.JsonElement> e : products.entrySet()) {
            JsonObject q = e.getValue().getAsJsonObject().getAsJsonObject("quick_status");
            // buyPrice = instant-buy price (lowest sell offer); sellPrice = instant-sell price (highest buy order)
            double instaBuy = q.get("buyPrice").getAsDouble();
            double instaSell = q.get("sellPrice").getAsDouble();
            double hourly = Math.min(q.get("buyMovingWeek").getAsDouble(),
                                     q.get("sellMovingWeek").getAsDouble()) / 168.0;
            if (instaBuy <= 0 || instaSell <= 0) continue;

            double buyOrder = instaSell + 0.1;   // you place a buy order just above the top one
            double sellOrder = instaBuy - 0.1;   // you place a sell offer just below the lowest one
            double profit = sellOrder * (1 - Config.TAX) - buyOrder;
            double margin = profit / buyOrder * 100.0;

            if (profit <= 0 || margin < Config.MIN_MARGIN_PCT || hourly < Config.MIN_HOURLY_VOLUME) continue;
            // Score = rough coins/hour you could make per slot-limited flip, capped by volume.
            double score = profit * Math.min(hourly, Config.SCORE_VOLUME_CAP);
            out.add(new Flip(e.getKey(), pretty(e.getKey()), buyOrder, sellOrder, profit, margin, hourly, score));
        }
        out.sort(Comparator.comparingDouble(Flip::score).reversed());
        return out.size() > Config.LIST_SIZE ? out.subList(0, Config.LIST_SIZE) : out;
    }

    private static String pretty(String id) {
        StringBuilder sb = new StringBuilder();
        for (String w : id.split("_")) {
            if (w.isEmpty()) continue;
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1).toLowerCase()).append(' ');
        }
        return sb.toString().trim();
    }
}

Bazaar Flipper (Fabric, Minecraft 26.1.x)
Display-only. Reads the public Hypixel Bazaar API and draws a list on the RIGHT side of the Bazaar menu.

Build:
1. Install JDK 25.
2. Copy gradlew, gradlew.bat and the gradle/ folder from the Fabric example mod into this folder
   (or run: gradle wrapper --gradle-version 9.3).
3. Run: ./gradlew build
4. Jar appears in build/libs/ (use the one WITHOUT "-sources"). Put it in .minecraft/mods with Fabric API.

No PC? Build online: upload this project to a GitHub repo (keep the .github folder).
Actions tab -> "build" -> download the "bazaar-flipper-jar" artifact. The zip inside holds the .jar.
